//
//  PetImageCell.swift
//  TakeMyPaws
//
//  Created by BUDLCIT on 2024. 01. 31..
//

import UIKit

class PetImageCell: UICollectionViewCell {

    @IBOutlet weak var petImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
