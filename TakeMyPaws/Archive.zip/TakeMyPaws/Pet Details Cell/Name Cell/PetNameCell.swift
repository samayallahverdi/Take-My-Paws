//
//  PetNameCell.swift
//  TakeMyPaws
//
//  Created by BUDLCIT on 2024. 02. 01..
//

import UIKit

class PetNameCell: UICollectionViewCell {

    @IBOutlet weak var petName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
