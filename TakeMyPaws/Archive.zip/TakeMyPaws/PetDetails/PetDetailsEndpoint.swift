//
//  PetDetailsEndpoint.swift
//  TakeMyPaws
//
//  Created by BUDLCIT on 2024. 01. 31..
//

import Foundation

enum PetDetailsEndpoint: String {
    case details = "api/animals/"
}
