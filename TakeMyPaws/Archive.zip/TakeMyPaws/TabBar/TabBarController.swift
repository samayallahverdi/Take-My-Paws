//
//  TabBarController.swift
//  TakeMyPaws
//
//  Created by BUDLCIT on 2024. 01. 10..
//

import UIKit

class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
