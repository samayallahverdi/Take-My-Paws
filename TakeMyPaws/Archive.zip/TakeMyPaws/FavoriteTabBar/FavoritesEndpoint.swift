//
//  FavoritesEndpoint.swift
//  TakeMyPaws
//
//  Created by BUDLCIT on 2024. 02. 04..
//

import Foundation

enum FavoritesEndpoint: String {
    case favorites = "api/favorites"
}
