//
//  FavoritePetCell.swift
//  TakeMyPaws
//
//  Created by BUDLCIT on 2024. 02. 04..
//

import UIKit

class FavoritePetCell: UICollectionViewCell {

    @IBOutlet weak var genderImage: UIImageView!
    @IBOutlet weak var shelterName: UILabel!
    @IBOutlet weak var petName: UILabel!
    @IBOutlet weak var petImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
