//
//  PetDetailsController.swift
//  TakeMyPaws
//
//  Created by BUDLCIT on 2024. 01. 29..
//

import UIKit

class PetDetailsController: UIViewController {
    
    var selectedId = 0

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

   
}
