//
//  PetDetailsViewModel.swift
//  TakeMyPaws
//
//  Created by BUDLCIT on 2024. 01. 29..
//

import Foundation

struct PetDetailModel {
    let type: PetDetailType
}

enum PetDetailType {
    case image(String?)
    case name(String?)
    case info(PetInfo)
    case description(String?)
    
}

struct PetInfo {
    let gender: Bool?
    let energy: Int?
    let size: String?
}

class PetDetailsViewModel {
    
    var petDetails = [PetDetailModel]()
    var success: (() -> Void)?
    var error: ((String) -> Void)?
    
    private let manager = PetDetailsManager()
    
//    func getMovieInfoItems(petId: Int?) {
//        manager.getData(idNumber: petId, endpoint: .main) { data, errorMessage in
//            if let errorMessage {
//                self.error?(errorMessage)
//            } else if let data {
////                self.petDetails.append(.init(type: .image(data[indexPath.item].imageOne))))
////                self.petDetails.append(.init(type: .name(data[indexPath.item].nameEn)))
////                self.movieItems.append(.init(type: .info(.init(rating: "\(data.voteAverage ?? 0.0)",
////                                                               genres: data.genres ?? [], length: "\(data.runtime ?? 0)",
////                                                               language: data.spokenLanguages ?? []))))
////                self.movieItems.append(.init(type: .description(data.overview)))
//                self.success?()
//            }
//        }
//    }
}
