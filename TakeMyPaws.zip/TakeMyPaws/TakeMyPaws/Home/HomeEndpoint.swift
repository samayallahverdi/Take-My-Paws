//
//  HomeEndpoint.swift
//  TakeMyPaws
//
//  Created by BUDLCIT on 2024. 01. 09..
//

import Foundation

enum HomeEndpoint: String {
    case main = "api"
}
