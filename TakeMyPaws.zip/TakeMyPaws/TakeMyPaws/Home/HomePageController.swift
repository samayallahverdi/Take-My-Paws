//
//  HomePageController.swift
//  TakeMyPaws
//
//  Created by BUDLCIT on 2024. 01. 09..
//

import UIKit

class HomePageController: UIViewController {
    
    @IBOutlet weak var homeCollection: UICollectionView!
    var viewModel = HomePageViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        homeCollection.register(UINib(nibName: "HomePageCell", bundle: nil), forCellWithReuseIdentifier: "HomePageCell")
       
        configureViewModel()
    }
    
    func configureViewModel() {
      
        viewModel.getHomeDetails()
        viewModel.error = { errorMessage in
            print("Error: \(errorMessage)")
        }
        viewModel.success = {
            self.homeCollection.reloadData()
        }
    }
    
    @IBAction func searchTextField(_ sender: UITextField) {
//           if let text = sender.text {
//        viewModel.search(key: text)
//    } else {
//        viewModel.home.removeAll()
//    }
//        // viewModel.success kapanı
//        viewModel.success = {
//            self.homeCollection.reloadData()
//        }
       }

     
    
    
    @IBAction func seeAllButtonTapped(_ sender: Any) {
        let controller = storyboard?.instantiateViewController(withIdentifier: "SeeAllController") as! SeeAllController
        navigationController?.show(controller, sender: nil)
    }
}
extension HomePageController: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        viewModel.home.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomePageCell", for: indexPath) as! HomePageCell
        let pet = viewModel.home[indexPath.item]
        cell.petName.text = pet.nameEn
        cell.petImage.loadImage(url: pet.imageOne ?? "")
        cell.petAdress.text = pet.shelterName

        if viewModel.home[indexPath.item].gender == true {
            cell.gerderImage.image = UIImage(named: "male")
        } else {
            cell.gerderImage.image = UIImage(named: "female")
        }
        
//        cell.tag = indexPath.item
//        cell.delegate = self
//        
        return cell
    }
}
//extension HomePageController: HomePageCellDelegate {
//    func didTapFavoriteButton(index: Int) {
//        <#code#>
//    }
//
//
//}
