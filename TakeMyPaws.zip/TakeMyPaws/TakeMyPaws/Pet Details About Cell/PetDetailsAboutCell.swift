//
//  PetDetailsAboutCell.swift
//  TakeMyPaws
//
//  Created by BUDLCIT on 2024. 01. 11..
//

import UIKit

class PetDetailsAboutCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
